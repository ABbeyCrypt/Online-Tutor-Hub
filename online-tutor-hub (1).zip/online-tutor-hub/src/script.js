// Placeholder for form submissions and validation
document.getElementById("student-form").addEventListener("submit", function (event) {
  event.preventDefault();
  alert("Student registration form submitted.");
});

document.getElementById("tutor-form").addEventListener("submit", function (event) {
  event.preventDefault();
  alert("Tutor registration form submitted. Please make the payment.");
});

document.getElementById("login-form").addEventListener("submit", function (event) {
  event.preventDefault();
  alert("Login form submitted.");
});
